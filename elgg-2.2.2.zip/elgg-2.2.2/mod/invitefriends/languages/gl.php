<?php
return array(

	'friends:invite' => 'Invitar amigos',
	
	'invitefriends:registration_disabled' => 'Desactivouse o rexistro de novas contas de usuario no sitio. Non pode invitar a novos usuarios.',
	
	'invitefriends:introduction' => 'Para invitar a contactos a unirse a vostede nesta rede, escriba os seus enderezos de correo electrónicos, e recibirán unha mensaxe coa súa invitación.',
	'invitefriends:emails' => 'Enderezos de correo (un por liña)',
	'invitefriends:message' => 'Mensaxe',
	'invitefriends:subject' => 'Invitación para unirse a %s',

	'invitefriends:success' => 'Enviáronse as invitacións.',
	'invitefriends:invitations_sent' => 'Invitacións enviadas: %s. Ocorreron os seguintes problemas:',
	'invitefriends:email_error' => 'Os seguintes enderezos non son válidos: %s.',
	'invitefriends:already_members' => 'Os seguintes enderezos corresponden a membros actuais do sitio: %s.',
	'invitefriends:noemails' => 'Non escribiu ningún enderezo de correo electrónico',
	
	'invitefriends:message:default' => 'Ola.

Quero invitarte a unirte á miña rede en %s.',

	'invitefriends:email' => 'Esta é unha invitación para que se una a %s, enviada de parte de %s, que incluíu a seguinte mensaxe:

%s

Para unirse, siga esta ligazón:

%s

Cando cree a súa conta, a persoa que lle enviou a invitación convertirase automaticamente no seu contacto.',
	
);
