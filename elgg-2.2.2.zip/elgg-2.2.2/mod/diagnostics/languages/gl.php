<?php
return array(
	'admin:administer_utilities:diagnostics' => 'Diagnósticos do sistema',
	'diagnostics' => 'Diagnósticos do sistema',
	'diagnostics:report' => 'Informe de diagnósticos',
	'diagnostics:description' => 'O seguinte informe de diagnósticos pode resultar útil para diagnosticar problemas con Elgg. Pode que os desenvolvedores de Elgg lle pidan que anexe estes datos cando informe dun erro.',
	'diagnostics:header' => '========================================================================
Informe de diagnósticos de Elgg
Xerado %s por %s.
========================================================================

',
	'diagnostics:report:basic' => '
Elgg, publicación %s, versión %s.

------------------------------------------------------------------------',
	'diagnostics:report:php' => '
PHP info:
%s
------------------------------------------------------------------------',
	'diagnostics:report:plugins' => '
Complementos instalados e detalles:

%s
------------------------------------------------------------------------',
	'diagnostics:report:md5' => '
Ficheiros instalados e sumas de comprobación:

%s
------------------------------------------------------------------------',
	'diagnostics:report:globals' => '
Variábeis globais:

%s
------------------------------------------------------------------------',
);