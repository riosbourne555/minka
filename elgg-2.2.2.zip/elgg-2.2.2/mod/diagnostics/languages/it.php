<?php
return array(
	'admin:administer_utilities:diagnostics' => 'Diagnostica di sistema',
	'diagnostics' => 'Diagnostica di sistema',
	'diagnostics:report' => 'Rapporto di diagnostica',
	'diagnostics:description' => 'Il rapporto di diagnostica seguente può essere utile per diagnosticare problemi con Elgg. Gli sviluppatori di elg possono richiederlo come allegato alla segnalazione di bug.',
	'diagnostics:header' => '========================================================================
Rapporto di diagnostica Elgg
Generato %s da %s
========================================================================

',
	'diagnostics:report:basic' => '

Elgg rlascio %s, versione %s

------------------------------------------------------------------------',
	'diagnostics:report:php' => '
Informazioni PHP:
%s
------------------------------------------------------------------------',
	'diagnostics:report:plugins' => '
Plugin installati e dettagli:

%s
------------------------------------------------------------------------',
	'diagnostics:report:md5' => '
Files installati e checksums:

%s
------------------------------------------------------------------------',
	'diagnostics:report:globals' => '
Variabili Globali:

%s
------------------------------------------------------------------------',
);