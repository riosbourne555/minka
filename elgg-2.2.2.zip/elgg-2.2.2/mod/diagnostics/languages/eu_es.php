<?php
return array(
	'admin:administer_utilities:diagnostics' => 'Sistemako diagnostikoak',
	'diagnostics' => 'Sistemako diagnostikoak',
	'diagnostics:report' => 'Diagnostikoen txostenak',
	'diagnostics:description' => 'Hurrengo diagnostiko txostena erabilgarria izan daiteke Elgg-ekin dauden arazoak aztertzeko. Elgg-eko garatzaileak hau eranstea eskatu dezakete programazio-errore txostenean.',
	'diagnostics:header' => '========================================================================
Elgg-eko Diagnostikoaren txostena
Sortua: %s Nork: %s
========================================================================

',
	'diagnostics:report:basic' => '
Elgg argitalpen %s, bertsioa %s

------------------------------------------------------------------------',
	'diagnostics:report:php' => '
PHP info:
%s
------------------------------------------------------------------------',
	'diagnostics:report:plugins' => '
Instalatutako pluginak eta xehetasunak:

%s
------------------------------------------------------------------------',
	'diagnostics:report:md5' => '
Instalatutako fitxategiak eta egiaztapeneko batura:

%s
------------------------------------------------------------------------',
	'diagnostics:report:globals' => '
Aldagai orokorrak:

%s
------------------------------------------------------------------------',
);