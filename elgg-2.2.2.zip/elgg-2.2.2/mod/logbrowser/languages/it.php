<?php
return array(
	'admin:administer_utilities:logbrowser' => 'Log browser',
	'logbrowser' => 'Navigatore di Resoconti',
	'logbrowser:browse' => 'Naviga il sistema dei resoconti',
	'logbrowser:search' => 'Affina i risultati',
	'logbrowser:user' => 'Username da cercare',
	'logbrowser:starttime' => 'Tempo di partenza (per esempio "lunedi scorso", "1 ora fa").)',
	'logbrowser:endtime' => 'Fino a',

	'logbrowser:explore' => 'Esplora resoconto',

	'logbrowser:date' => 'Date and time',
	'logbrowser:ip_address' => 'IP address',
	'logbrowser:user:name' => 'User',
	'logbrowser:user:guid' => 'User GUID',
	'logbrowser:object' => 'Object type',
	'logbrowser:object:guid' => 'Object GUID',
	'logbrowser:action' => 'Action',
);