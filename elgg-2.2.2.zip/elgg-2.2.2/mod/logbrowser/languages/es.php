<?php
return array(
	'admin:administer_utilities:logbrowser' => 'Navegador de registros',
	'logbrowser' => 'Navegador de registros',
	'logbrowser:browse' => 'Navegar por los registros del sistema',
	'logbrowser:search' => 'Buscar',
	'logbrowser:user' => 'Nombre de usuario a buscar',
	'logbrowser:starttime' => 'Fecha/hora de inicio (por ejemplo, "&uacute;ltimo lunes" o "1 hora atr&aacute;s")',
	'logbrowser:endtime' => 'End time',

	'logbrowser:explore' => 'Explorar registros',

	'logbrowser:date' => 'Fecha y hora',
	'logbrowser:ip_address' => 'Direcci&oacute;n IP',
	'logbrowser:user:name' => 'Uusario',
	'logbrowser:user:guid' => 'GUID de usuario',
	'logbrowser:object' => 'Tipo de objeto',
	'logbrowser:object:guid' => 'GUID de objeto',
	'logbrowser:action' => 'Acci&oacute;n',
);