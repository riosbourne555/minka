<?php

return array(

	'friends:all' => 'Lagun guztiak',

	'notifications:subscriptions:personal:description' => 'Jakinarazpenak jaso zure edukian ekintzak burutzen direnean',
	'notifications:subscriptions:personal:title' => 'Jakinarazpen pertsonalak',

	'notifications:subscriptions:friends:title' => 'Lagunak',
	'notifications:subscriptions:friends:description' => 'Behean lagunen bilduma dago. Hauek aukeratuta bertako erabiltzaileen jakinarazpenak aktibatuko dira.',
	'notifications:subscriptions:collections:edit' => 'Partekatutako atzipen jakinarazpenak editatzeko klikatu hemen.',

	'notifications:subscriptions:changesettings' => 'Jakinarazpenak',
	'notifications:subscriptions:changesettings:groups' => 'Talde jakinarazpenak',

	'notifications:subscriptions:title' => 'Erabiltzailekiko jakinarazpenak',
	'notifications:subscriptions:description' => 'Zure lagunek eduki berri bat sortzen dutenean jakinarazpenak jasotzeko (oinarri banakako baten), bilatu hauek behean eta aukeratu erabili nahi duzun jakinarazpen metodoa.',

	'notifications:subscriptions:groups:description' => 'Kide zaren talde bateko eduki berriaren jakinarazpenak jasotzeko, bilatu eta aukeratu behean nahiago duzun jakinarazpen metodoa(k).',

	'notifications:subscriptions:success' => 'Zure jakinarazpen ezarpenak gorde egin dira.',

);
