<?php

return array(

	'friends:all' => 'Totes les teves amistats',

	'notifications:subscriptions:personal:description' => 'Rebre notificacions quan es modifiquin els teus continguts',
	'notifications:subscriptions:personal:title' => 'Notificacions personals',

	'notifications:subscriptions:friends:title' => 'Contactes',
	'notifications:subscriptions:friends:description' => 'Això és una col·lecció automàtica de les teves amigues. Per rebre actualitzacions, selecciona-ho a sota. Això afectarà les usuàries que corresponguin amb el panell principal de notificacions al final de la pàgina.',
	'notifications:subscriptions:collections:edit' => 'Modifica les opcions de les amistats',

	'notifications:subscriptions:changesettings' => 'Notificacions',
	'notifications:subscriptions:changesettings:groups' => 'Notificacions de grup',

	'notifications:subscriptions:title' => 'Notificacions per usuaris',
	'notifications:subscriptions:description' => 'Per a rebe notificacions quan les teves amistats creïn nou contingut, cerca\'ls per la xarxa i escull el tipus de notificació que vols rebre.',

	'notifications:subscriptions:groups:description' => 'Per a rebre notificacions quan s\'afegeixi nou contingut a un grup del que en formes part, cerca\'l i escull el tipus de notificació que vols rebre',

	'notifications:subscriptions:success' => 'La teva configuració de notificacions s\'ha desat correctament.',

);
