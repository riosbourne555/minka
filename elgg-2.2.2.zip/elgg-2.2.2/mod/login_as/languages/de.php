<?php
/**
 * German strings
 */

return array(
	'login_as:login_as' => 'Einloggen als',
	'login_as:logged_in_as_user' => 'Du bist nun als %s eingeloggt.',

	'login_as:return_to_user' => 'Ausloggen als %s',

	'login_as:unknown_user' => 'Benutzer unbekannt. Einloggen nicht möglich.',
	'login_as:could_not_login_as_user' => 'Einloggen als %s fehlgeschlagen.',
);
