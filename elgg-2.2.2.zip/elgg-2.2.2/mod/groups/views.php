<?php

return [
	'default' => [
		'groups/' => __DIR__ . '/graphics',
	],
];
