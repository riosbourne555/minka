<?php
/**
 * CSS for user validation by email
 */
?>
/*<style>*/

.uservalidation-module > .elgg-head * {
	color: white;
}
.uservalidation-module > .elgg-body * {
	color: #333;
}