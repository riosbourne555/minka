<?php
	/*include('/var/www/html/elgg/mod/tap_editor/almacenar.php');*/
	require_once('/var/www/boca/src/db.php');
	require_once('Catalogo.php');
		$catalogos = Catalogo::getCatalogos();
		$miCatalogo = 1;
		$prob = DBGetFullProblemData(1,true);

		//n=".base64_encode($number)."&na=".base64_encode($name)."&fu=".base64_encode($fullname)."&ba=".base64_encode($basefilename)."&de=".base64_encode($descfilename).
		$number = base64_decode($_GET['n']);
		$name = base64_decode($_GET['na']);
		$fullname = base64_decode($_GET['fu']);
		$basefilename = base64_decode($_GET['ba']);
		$descfilename = base64_decode($_GET['de']);
		$relacion = Catalogo::getRelacion($number);

		//$union = array();
		//echo count($relacion);


		//var_dump($relacion);
		//var_dump($union);

		//foreach($catalogos as $catalogo){
//}
		//exit;
		$formulario = "	
			<style type=\"text/css\">
				.right{float:right;}
				.left{float:left;}
			</style>

			<script src=\"https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js\"></script>

			<script>
				$(document).ready(function(){
	        		$(\"#faz\").hide();					
	   				$(\"#escondefaz\").click(function(){
	        			$(\"#faz\").hide();
	        			$(\"#fcz\").show();
	    			});
	   				$(\"#escondefcz\").click(function(){
	        			$(\"#fcz\").hide();
	        			$(\"#faz\").show();
	    			});
				});
			</script>

			<script>
				require(['elgg/ckeditor'], 
					    function (elggCKEditor) 
					    {
					       	elggCKEditor.bind('.elgg-input-longtext');
					    });
			</script>


			<div class = 'form-group col-md-12 '>

			    <button type=\"button\" class=\"btn btn-basic pull-left col-sm-3\" id=\"escondefaz\">
			    	<b>Cargar Zip</b>
			    </button>

			    <button type=\"submit\" class=\"btn btn-basic col-sm-3 pull-right\" id=\"escondefcz\">
					<b>Armar Zip</b>
				</button>

			</div>


					<!-- Armado de un nuevo ZIP -->
					<div id='faz' class=\"form-group\">
						
						<form  name='form2' enctype='multipart/form-data' method='post' action='/run/adminprocess.php' class=\"form-horizontal\">
						  	
						  	<input type=hidden name='noflush' value='true' />
						  	<input type=hidden name='confirmation' value='noconfirm' />
						  	
						  	<textarea rows='10' cols='50' id='problemdesc' name='problemdesc' value='Descripcion del problema' class='elgg-input-longtext' data-editor-opts='{&quot;disabled&quot;:false,&quot;state&quot;:&quot;visual&quot;}'>
							</textarea>
			
					        <script>
					        	require([\'elgg/ckeditor\'], 
					                function (elggCKEditor) 
					                {
					                	elggCKEditor.bind(\'.elgg-input-longtext\');
					                });
					        </script>

					        <br><br>

					        <div class=\"form-group\">
    							<label class=\"control-label col-sm-2\" >ZIP</label>
    							<div class=\"col-sm-10\">
      								<input type=\"text\" class=\"form-control\" placeholder=\"Ingrese nombre del ZIP\" name='inputfilename' value='$name'>
    							</div>
  							</div>

  							<div class=\"form-group\">
    							<label class=\"control-label col-sm-2\" >Número</label>
    							<div class=\"col-sm-10\">
      								<input type=\"text\" class=\"form-control\" placeholder=\"Ingrese número si es necesario\" name='problemnumber' value='$number'>
    							</div>
  							</div>

				        	
  							<div class=\"form-group\">
    							<label class=\"control-label col-sm-2\" >Nombre Corto</label>
    							<div class=\"col-sm-10\">
      								<input type=\"text\" class=\"form-control\" placeholder=\"Ingrese Nombre Corto\" name='problemname' value=''>
      								<span class=\"badge badge-secondary\">Usualmente una letra, sin espacios</span>
    							</div>
  							</div>	
							
							
							<div class=\"form-group\">
    							<label class=\"control-label col-sm-2\" >Problema</label>
    							<div class=\"col-sm-10\">
      								<input type=\"text\" class=\"form-control\" placeholder=\"Ingrese Nombre del problema\" name='fullname' value='$fullname'>
    							</div>
  							</div>


							<div class=\"form-group\">
    							<label class=\"control-label col-sm-2\" >Clase</label>
    							<div class=\"col-sm-10\">
      								<input type=\"text\" class=\"form-control\" placeholder=\"Ingrese Nombre de la clase\" name='basename' value=''>
      								<span class=\"badge badge-secondary\">Alias: nombre de la clase que se espera tenga el main</span>
    							</div>
  							</div>					        	

							
							<div class=\"form-group\">
    							<label class=\"control-label col-sm-2\" >Entrada</label>
    							<div class=\"col-sm-10\">
      								<input type=\"file\" class=\"form-control-file col-sm\" placeholder=\"Ingrese Archivo de Entrada\" name='probleminput' value=''>
    							</div>
  							</div>
	
							
							<div class=\"form-group\">
    							<label class=\"control-label col-sm-2\" >Salida</label>
    							<div class=\"col-sm-10\">
      								<input type=\"file\" class=\"form-control-file col-sm\" placeholder=\"Ingrese Archivo de Salida\" name='problemsol' value=''>
    							</div>
  							</div>


  							<div class=\"form-group\">
    							<label class=\"control-label col-sm-2\" >Tiempo</label>
    							<div class=\"col-sm-10\">
      								<input type=\"text\" class=\"form-control\" placeholder=\"Ingrese Tiempo Limite\" name='timelimit' value=''>
      								<span class=\"badge badge-secondary\">Opcional: usar una ',' seguida por el numero de repeticiones a ejecutar</span>
    							</div>
  							</div>


  							<label>Elija el catalogo a que va a pertenecer</label>
							
							<div class=\"form-group col-md-11 pull-right\">    
							    
							    <select multiple class=\"form-control\" name='idCatalogo[]'>";

									foreach($catalogos as $catalogo)
									{
										$formulario .= "<option value='".$catalogo->getIdCatalogo()."'>".$catalogo->getNombre()."</option>";
									}
										
									$formulario .=

								"</select>
							</div>
								

							<br/>

						    <div class = 'form-group col-md-11 pull-right'>

							    <button type=\"reset\" class=\"btn btn-danger pull-left col-sm-2\" name='Submit4'>
							    	Limpiar
							    </button>

							    <button type=\"submit\" class=\"btn btn-success col-sm-2 pull-right\" name='Submit5' onClick='conf4()'>
									Enviar
								</button>

							</div>

						</form>
					</div>


					
					<!-- CARGAR EL ZIP -->
					<div id='fcz' class=\"form-group\">
						
						<form  name='form2' enctype='multipart/form-data' method='post' action='/run/cargazip.php' class=\"form-horizontal \">
							
							<textarea rows='10' cols='50' id='problemdesc' name='problemdesc' value='Descripcion del problema' class='elgg-input-longtext' data-editor-opts='{&quot;disabled&quot;:false,&quot;state&quot;:&quot;visual&quot;}'>
							</textarea>

							<div class=\"form-group\">
    							<label class=\"control-label col-sm-2\" >Número</label>
    							<div class=\"col-sm-10\">
      								<input type=\"text\" class=\"form-control\" placeholder=\"Ingrese número si es necesario\" name='problemnumber' value='$number'>
    							</div>
  							</div>

  							<div class=\"form-group\">
    							<label class=\"control-label col-sm-2\" >Nombre Corto</label>
    							<div class=\"col-sm-10\">
      								<input type=\"text\" class=\"form-control\" placeholder=\"Ingrese Nombre Corto\" name='problemname' value='$name'>
      								<span class=\"badge badge-secondary\">Usualmente una letra, sin espacios</span>
    							</div>
  							</div>

  							<div class=\"form-group\">
    							<label class=\"control-label col-sm-2\" >Paquete ZIP</label>
    							<div class=\"col-sm-10\">
      								<input type=\"file\" class=\"form-control-file col-sm\" placeholder=\"Ingrese Archivo de ZIP del Problema\" name='probleminput' value=''>
    							</div>
  							</div>
						

						    <label>Elija el catalogo a que va a pertenecer</label>
						    <br> 

						    <div class=\"form-group col-md-11 pull-right\"> 
							    
							    <select multiple class=\"form-control\" name='idCatalogo[]'>";

									foreach($catalogos as $catalogo)
									{

										$formulario .= "<option value='".$catalogo->getIdCatalogo()."'>".$catalogo->getNombre()."</option>";
									}
										
									$formulario .=

								"</select>
							</div>
							";

							$formulario .="

							</br>
			
							<label>Descripcion breve</label>
							<textarea rows='2' cols='2' id='descripcion_breve' name='descripcion_breve' value='descripcion_breve' class='elgg-input-longtext' data-editor-opts='{&quot;disabled&quot;:false,&quot;state&quot;:&quot;visual&quot;}'>
							</textarea>
							<br/><br/>
						    <div class=\"form-group col-md-11 pull-right\"> 

							    <button type=\"reset\" class=\"btn btn-danger pull-left col-sm-2\" name='Submit4'>
							    	Limpiar
							    </button>

							    <button type=\"submit\" class=\"btn btn-success col-sm-2 pull-right\" name='Submit5'>
									Enviar
								</button>

							</div>
			
						</form>
					</div>

		";
	return $formulario;
?>
