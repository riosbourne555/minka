

<html>
	<head>
		<title>Pagina de inicio casa nico</title>
	</head>
	<body>
		<h1>Hola! Bienvenido! para entrar en boca, presiona el link de abajo</h1>
		<a href="/boca/"><button><b>Boca</b></button></a>
		<!--<a href="form.html">form</a>
		<a href="formcp.html">Construir problema</a>
		<a href="logout.php">Logout</a>
		<a href="login.php">Login</a>
		-->
		<a href="admin.php"><button><b>Admin Functions</b></button></a>
		<a href="run.php"><button><b>User Functions</b></button></a>
		<a href="createusr.php"><button><b>Create User</b></button></a>

		<center>
<!--<?php


//echo "<pre>";

//echo print_r($_SESSION, TRUE);

//echo "</pre>";

//session_start(); 


//var_dump($_SESSION);

?>	-->
	</center>
	</body>
</html>
