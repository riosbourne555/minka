<?php
	include('/var/www/html/run/config/DataBase.php');
	class Catalogo
	{
		private $idCatalogo;
		private $nombre;
		
		public function __construct($idCatalogo, $nombre = "")
		{
			$this->setIdCola($idCatalogo);
			$this->setNombre($nombre);
		}
		
		public function getIdCatalogo()
		{
			return $this->idCatalogo;
		}
		
		public function getNombre()
		{
			return $this->nombre;
		}
		
		public function setIdCola($idCatalogo)
		{
			$this->idCatalogo = $idCatalogo;
		}
		
		public function setNombre($nombre)
		{
			$this->nombre = $nombre;
		}
		
		public static function getCatalogos()
		{
			try
			{
				$mdb = DataBase::getDb('mysql', 'elggadd', 2);
				$sql = "SELECT * FROM catalogo";
				$temp = $mdb->prepare($sql);
				$temp->execute();
				$resultado = $temp->fetchAll();
				
				foreach($resultado as $res){
					$data[] = new Catalogo($res['id_catalogo'], $res['nombre_catalogo']);
				}
			}

			catch (PDOException $e)
			{
				print "ERROR<br>". $e->getMessage();
			}

			return $data;
		}
		
		public static function getMiCatalogo($id)
		{
			try
			{
				$mdb = DataBase::getDb('mysql', 'elggadd', 2);
				$sql = "SELECT id_catalogo FROM ejercicios WHERE id_ex = ".$id;
				$temp = $mdb->prepare($sql);
				$temp->execute();
				$resultado = $temp->fetchAll();
				$data = $resultado[0]['id_catalogo'];
				$mdb = null;
			}

			catch (PDOException $e)
			{
				print "ERROR". $e->getMessage();
			}

			return $data;
		}
	}
?>
