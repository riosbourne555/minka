<?php
    elgg_register_event_handler('init', 'system', 'tap_editor_init');
	
    function tap_editor_init()
    {
        $funcion = 'editor_page_handler';
        elgg_register_page_handler('tap_editor', $funcion);
    }

    function editor_page_handler()
    {		
		if(elgg_is_admin_logged_in())
		{
			$form = require_once("/var/www/html/run/admin.php");
			$params = cargaArray('CARGAR NUEVO PROBLEMA', $form, '');
			include('body.php');    
		}

		else
		{
			$form = "No tienes permiso";
			$params = cargaArray('CARGAR NUEVO PROBLEMA', $form, '');
			include('body.php');    
		}
    }
?>
