<?php  
    $body = elgg_view_layout('content', $params);
    echo elgg_view_page('tap', $body);
?>